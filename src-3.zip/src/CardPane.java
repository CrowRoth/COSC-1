/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RVanclea
 */
import java.io.File;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.control.*;

public class CardPane extends GridPane{
    Image[] cards = new Image[55];
    ImageView[] hand = new ImageView[5];
    Button btn = new Button();
    CheckBox[] cb = new CheckBox[5];
    Deck deck = new Deck();
    Label left = new Label("Cards left: " + deck.getLeft());
    
    private int status = 1;
    
    
   
    CardPane() {
        super();
        init();
    }
    
    private void init(){
        initDeck();
        initHand();
        
        for(int i = 0; i < 5; i++){
            this.add(hand[i], i, 0);
        }
        for(int i = 0; i < 5; i++){
            cb[i]= new CheckBox();
            this.add(cb[i],i,1);
        }
        this.add(btn,2,2,2,2);
        this.add(left, 0, 3);
        main();
    }
    
    private void main(){
        if(status == 1){
            if(deck.getLeft() < 10){
                reset();
                left.setText("Cards left: " + deck.getLeft());
            }
            for(int i = 0; i < 5; i++){
                cb[i].setVisible(false);
            }
            btn.setText("Deal new hand");
            btn.setOnAction(e -> newhand());
        }
        if(status == 2){
            for(int i = 0; i < 5; i++){
                cb[i].setVisible(true);
            }
            
            btn.setText("Change selected cards");
            btn.setOnAction(e -> change());
        }
    }
    
    private void newhand(){
        for(int i = 0; i < 5; i++){
            changeCard(i);
        }
        status = 2;
        main();
    }
    
    private void change(){
        for(int i = 0; i < 5; i++){
            if (cb[i].isSelected()){
                changeCard(i);
                cb[i].setSelected(false);
            }
        }
        status = 1;
        main();
    }
    
    private void changeCard(int i){
        int num = deck.deal();
        if (num == 0){
            reset();
            return;
        }
        else{
        hand[i].setImage(cards[num]);
        }
        left.setText("Cards left: " + deck.getLeft());
    }
    
    public void reset(){
        deck.shuffle();
        for(int i=0;i<5;i++){
            hand[i].setImage(cards[0]);
        }
    }
    
    private void initHand(){
        for(int i = 0; i < 5; i++){
            hand[i]= new ImageView();
            hand[i].setImage(cards[0]);
            hand[i].setFitWidth(100);
            hand[i].setPreserveRatio(true);
            hand[i].setSmooth(true);
            hand[i].setCache(true);
        }
         
    }
    
    private void initDeck(){
    
        String fname;
        for(int i = 0; i < 55; i++){
            fname = "src/cards/" + Integer.toString(i) + ".png";
            cards[i] = new Image(new File(fname).toURI().toString());
        }
        
    }
}
