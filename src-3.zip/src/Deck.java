
public class Deck {
    private boolean[] dealt;
    private int left;
    
    Deck(){
        dealt = new boolean[52];
        shuffle();
    }
    
    public void shuffle(){
        for(int i=0;i<52;i++){
            dealt[i]=false;
        }
        left = 52;
    }
    
    public int getLeft(){return left;}
    
    public int deal(){
        int num = (int)(Math.random()*left) + 1;
        int count = 0;
        
        for(int i=0;i<52;i++){
            if (!dealt[i]){
                count++;
                if(count == num){
                    dealt[i]=true;
                    left--;
                    return(i+1);
                }
                
            }
        }
        
        return 0;
    }

}
