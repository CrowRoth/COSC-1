
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;

public class Launcher extends Application {
    @Override // Override the start method in the Application class
    public void start (Stage primaryStage) throws IOException{
        Badapaka game = new Badapaka(); // Create a ball pane

        // Pause and resume animation
        
        

        game.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.LEFT) {
                game.moveplayerleft();
            }
            if (e.getCode() == KeyCode.RIGHT) {
                game.moveplayerright();
            }
            if (e.getCode() == KeyCode.UP) {
                game.moveplayerup();
            }
            if (e.getCode() == KeyCode.DOWN) {
                game.moveplayerdown();
            }
            if (e.getCode() == KeyCode.SPACE) {
                game.missle();
            }
            if (e.getCode() == KeyCode.ESCAPE) {
                game.pause();
            }
            if (e.getCode() == KeyCode.ENTER) {
                game.reset();
            }
        });  
        

        // Create a scene and place it in the stage
        Scene scene = new Scene(game, 300, 340);
        primaryStage.setTitle("Spaceshooter"); 
        primaryStage.setScene(scene); 
        primaryStage.sizeToScene();
        primaryStage.show();
        primaryStage.setMinWidth(primaryStage.getWidth());
        primaryStage.setMinHeight(primaryStage.getHeight()); 

        game.requestFocus();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
