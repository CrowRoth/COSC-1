import java.io.File;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.util.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class Badapaka extends GridPane {
    private Image[] ships = new Image[6],asteroid = new Image[5],bgpic = new Image[4],stars = new Image[4];
    private Image ship,hudd;
    private ImageView p,star,star2,bgp,bgp2,l;
    private ImageView[] roid = new ImageView[5];
    private int s=0,nnum=0,mnum=0,pause=0,count=0,mcount=0,L=1,powerx,powery,life=3,mm=1,powerup=0,ss=0,pcount=0,item;
    private int[] m = new int[5],n = new int[5];
    private double bgy=0,bgy2=-300,sty=0,sty2=-300,dy=1,px=145,py=280,chance=0,speed=2;
    private double[] mx = new double[5],my = new double[5],x = new double[5],y = new double[5],mxx= new double[3],pxx= new double[10],pyy = new double[10],d= new double[5],powx = new double[5],powy = new double[5];
    private Circle[] ac = new Circle[5];
    private Rectangle player = new Rectangle(px,py,10,10),missup = new Rectangle(powerx,powery,5,5),speedup = new Rectangle(powerx,powery,5,5);
    private Rectangle[] miss = new Rectangle[5];
    private Pane game;
    private Timeline[] missle = new Timeline[5],an= new Timeline[5];
    private Timeline asttimer,bg,str;
    private Label dir,Level,score = new Label("Score: " + s + "   Level: " + L);
    private HBox hud;
    protected MediaPlayer a,fire,music,mup,sup,xlife,thrust,crash;
    
    public Badapaka(){
        super();
        init();
        
        
        this.add(game,0,0);
        this.add(hud, 0, 1);
    }
    
    private void init(){
        hud = new HBox(10);
        dir = new Label("Controls\n  \u2191 \u2193 \u2190 \u2192 to move\nEsc to pause/unpause\nEnter to start new game.");
        
        initmusic();
        initgame();
        initimages();
        initimageviews();
        initanimations();
    } 
    
    private void initmusic(){
        a = new MediaPlayer(new Media(new File("src/audio/aexp1.mp3").toURI().toString()));
        fire = new MediaPlayer(new Media(new File("src/audio/missle.wav").toURI().toString()));
        music = new MediaPlayer(new Media(new File("src/audio/music.mp3").toURI().toString()));
        mup = new MediaPlayer(new Media(new File("src/audio/mup.mp3").toURI().toString()));
        sup = new MediaPlayer(new Media(new File("src/audio/speedup.mp3").toURI().toString()));
        xlife = new MediaPlayer(new Media(new File("src/audio/xlife.wav").toURI().toString()));
        thrust = new MediaPlayer(new Media(new File("src/audio/start.wav").toURI().toString()));
        crash = new MediaPlayer(new Media(new File("src/audio/dead.wav").toURI().toString()));
    }
    
    private void initgame(){
        player.setFill(Color.BLUE);
        missup.setFill(Color.RED);
        speedup.setFill(Color.BLUE);
        for(int i=0;i<5;i++) {
            x[i]=0;
            y[i]=0;
            ac[i]= new Circle(x[i],y[i],10);
            ac[i].setFill(Color.GREY);
            mx[i]=-1000;
            my[i]=-1000;
            miss[i] = new Rectangle(mx[i],my[i],2,4);
            miss[i].setFill(Color.RED);
            m[i]=0;
            n[i]=0;
        }
        
        music.setCycleCount(music.INDEFINITE);
        music.play();
        thrust.seek(new Duration(0));
        thrust.play();
        
        game = new Pane();
        game.setMinSize(300, 300);
        
        Level = new Label("Level: " + L);
        Level.layoutXProperty().bind(game.widthProperty().subtract(game.widthProperty()).divide(2));
        Level.layoutYProperty().bind(game.heightProperty().subtract(game.heightProperty()).divide(2));
        
        game.getChildren().add(Level);
        game.getChildren().add(player);
    }
    
    private void initimages() {
        String fname;
        fname = "src/images/Spaceships/01/" + Integer.toString(3) + ".png";
        ship = new Image(new File(fname).toURI().toString());
        for (int i=0;i<4;i++) {
            fname = "src/images/bg/" + Integer.toString(i) + ".png";
            bgpic[i] = new Image(new File(fname).toURI().toString());
            fname = "src/images/bg/stars/" + Integer.toString(i) + ".png";
            stars[i] = new Image(new File(fname).toURI().toString());
        }
        fname = "src/images/untitled.png";
        hudd = new Image(new File(fname).toURI().toString());
    }
    
    private void initimageviews() {
        bgp = new ImageView();
        bgp.setImage(bgpic[1]);
        bgp.setX(0);
        bgp.setY(0);
        bgp.setFitWidth(300);
        bgp.setPreserveRatio(true);
        bgp2 = new ImageView();
        bgp2.setImage(bgpic[1]);
        bgp2.setX(0);
        bgp2.setY(-300);
        bgp2.setFitWidth(300);
        bgp2.setPreserveRatio(true);
        game.getChildren().addAll(bgp,bgp2);
        
        star = new ImageView();
        star.setImage(stars[1]);
        star.setX(0);
        star.setY(0);
        star.setFitWidth(300);
        star.setPreserveRatio(true);
        star2 = new ImageView();
        star2.setImage(stars[1]);
        star2.setX(0);
        star2.setY(-300);
        star2.setFitWidth(300);
        star2.setPreserveRatio(true);
        game.getChildren().addAll(star,star2);
        
        p = new ImageView();
        p.setImage(ship);
        p.setX(px-26);
        p.setY(py-25);
        p.setFitWidth(60);
        p.setPreserveRatio(true);
        game.getChildren().add(p);
        
        l = new ImageView();
        l.setImage(hudd);
        l.setLayoutX(0);
        l.setLayoutY(300);
        l.setFitWidth(300);
        l.setPreserveRatio(true);
        hud.getChildren().addAll(l);
        
        for (int i=0;i<5;i++) {
            roid[i] = new ImageView();
            roid[i].setY(y[i]-10);
            roid[i].setFitWidth(20);
            roid[i].setPreserveRatio(true);
        }
    }
    
    private void initanimations(){
        str = new Timeline(
        new KeyFrame(Duration.millis(50), e -> movestars()));
        str.setCycleCount(Timeline.INDEFINITE);
        str.play();
        
        bg = new Timeline(
        new KeyFrame(Duration.millis(50), e -> movebgs()));
        bg.setCycleCount(Timeline.INDEFINITE);
        bg.play();
        
        asttimer = new Timeline(
        new KeyFrame(Duration.millis(1000), e -> ast()));
        asttimer.setCycleCount(Timeline.INDEFINITE);
        asttimer.delayProperty().setValue(Duration.seconds(5));
        asttimer.play();
        
        an[0] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(0)));
        an[0].setCycleCount(Timeline.INDEFINITE);
        
        an[1] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(1)));
        an[1].setCycleCount(Timeline.INDEFINITE);
        
        an[2] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(2)));
        an[2].setCycleCount(Timeline.INDEFINITE);
        
        an[3] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(3)));
        an[3].setCycleCount(Timeline.INDEFINITE);
        
        an[4] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(4)));
        an[4].setCycleCount(Timeline.INDEFINITE);
        
        missle[0] = new Timeline(
        new KeyFrame(Duration.millis(25), e -> movemissle(0)));
        missle[0].setCycleCount(Timeline.INDEFINITE);
        
        missle[1] = new Timeline(
        new KeyFrame(Duration.millis(25), e -> movemissle(1)));
        missle[1].setCycleCount(Timeline.INDEFINITE);
        
        missle[2] = new Timeline(
        new KeyFrame(Duration.millis(25), e -> movemissle(2)));
        missle[2].setCycleCount(Timeline.INDEFINITE);
        
        missle[3] = new Timeline(
        new KeyFrame(Duration.millis(25), e -> movemissle(3)));
        missle[3].setCycleCount(Timeline.INDEFINITE);
        
        missle[4] = new Timeline(
        new KeyFrame(Duration.millis(25), e -> movemissle(4)));
        missle[4].setCycleCount(Timeline.INDEFINITE);
    }
    
    private void movebgs() {
        bgy=bgy+.5;
        bgp.setY(bgy);
        bgy2=bgy2+.5;
        bgp2.setY(bgy2);
        if(bgy==300){
            bgy=-300;
        }
        if(bgy2==300){
            bgy2=-300;
        }
    }
    
    private void movestars() {
        sty=sty+1;
        star.setY(sty);
        sty2=sty2+1;
        star2.setY(sty2);
        if(sty==300){
            sty=-300;
        }
        if(sty2==300){
            sty2=-300;
        }
    }
    
    protected void moveast(int z){
        for(int i=0;i<5;i++) {
            for(int k=0;k<10;k++) {
                pxx[k]=px + k;
                pyy[k]=py + k;
                d[i]=Math.sqrt(Math.pow((pxx[k] - x[i]),2) + Math.pow((pyy[k] - y[i]),2));
                if(d[i]<=10) {
                    crash.seek(new Duration (0));
                    crash.play();
                    pause();
                    pause=2;
                    return;
                }
            }
        }
        
        if(y[z]==290){
            game.getChildren().removeAll(ac[z],roid[z]);
            count--;
            an[z].pause();
            y[z]=0;
            ac[z].setCenterY(y[z]);
            roid[z].setY(y[z]-10);
            nnum=z;
            n[z]=0;
            ast();
        }
        else{
            y[z] += dy;
        }
        ac[z].setCenterY(y[z]);
        roid[z].setY(y[z]-10);
    }
        
    protected void movemissle(int zz) {
        for(int i=0;i<5;i++) {
            for(int k=0;k<3;k++) {
                for(int o=0;o<5;o++) {
                    mxx[k]=mx[o] + k;
                    d[o]=Math.sqrt(Math.pow((mxx[k] - x[i]),2) + Math.pow((my[o] - y[i]),2));
                    if(d[o]<=10) {
                        powerx = (int) x[i]-2;
                        powery = (int) y[i]-2;
                        drop();
                        an[i].pause();    
                        game.getChildren().removeAll(ac[i],roid[i]);
                        count--;
                        nnum=i;
                        n[i]=0;
                        y[i]=0;
                        ac[i].setCenterY(y[i]);
                        roid[i].setY(y[i]-10);
                        missle[o].pause();
                        game.getChildren().remove(miss[o]);
                        mnum=o;
                        m[o]=0;
                        mcount--;
                        mx[o]=-1000;
                        my[o]=-1000;
                        miss[o].setX(mx[o]);
                        miss[o].setY(my[o]);
                        a.seek(new Duration(0));
                        a.play();
                        s++;
                        score.setText("Score: " + s + "   Level: " + L);
                        Level();
                        return;
                    }
                }
            }
        }
        if (my[zz] == 0){
            missle[zz].pause();
            game.getChildren().remove(miss[zz]);
            mcount--;
            mnum=zz;
            m[zz]=0;
            mx[zz]=-1000;
            my[zz]=-1000;
            miss[zz].setX(mx[zz]);
            miss[zz].setY(my[zz]);
        }
        else{
        my[zz] = my[zz] - 1;
        }

        miss[zz].setY(my[zz]);
    }
    
    protected void drop() { 
        if (pcount==0) {
            if (mm==1) {
            missup.setX(powerx);
            missup.setY(powery);
            game.getChildren().add(missup);
            pcount=1;
            item = 2;
            return;
            }
            chance = (int) (Math.random()*10);
            if (chance>=7){
                powerup = (int) (Math.random()*2);
                if(powerup==0) {
                    if(mm<5){
                        missup.setX(powerx);
                        missup.setY(powery);
                        game.getChildren().add(missup);
                        pcount=1;
                        item = 2;
                        return;
                    }
                }
                if (powerup==1){
                    if(ss<5) {
                        speedup.setX(powerx);
                        speedup.setY(powery);
                        game.getChildren().add(speedup);
                        pcount=1;
                        item = 3;
                        return;
                    }
                }
            }
        }
    }
    
    protected void Level(){
        if (s==20/s){
            life++;
        }
        switch(s){
            case 10:
                asttimer.stop();
                for(int i=0;i<5;i++){
                    an[i].stop();
                    y[i]=0;
                    n[i]=0;
                    ac[i].setCenterY(y[i]);
                    roid[i].setY(y[i]-10);
                    game.getChildren().removeAll(ac[i],roid[i]);
                }
                count=0;
                nnum=0;
                L=2;
                score.setText("Score: " + s + "   Level: " + L);
                dy=2;
                asttimer.delayProperty().setValue(Duration.seconds(5));
                asttimer.play();
                return;
            case 20:
                
                return;
            case 40:
                break;
            case 45:
                return;
            default:
                ast();
                break;
        }
    }
    
    protected void reset(){
        if(pause!=2) {
            return;
        }
        asttimer.stop();
        for(int i=0;i<5;i++){
            an[i].stop();
            y[i]=0;
            n[i]=0;
            ac[i].setCenterY(y[i]);
            roid[i].setY(y[i]-10);
            game.getChildren().removeAll(ac[i],roid[i]);
        }
        count=0;
        if (mcount>0) {
            for (int i=0;i<5;i++){
                missle[i].stop();
                if(mm>=i) {    
                    m[i]=0;
                    mx[i]=-1000;
                    my[i]=-1000;
                    miss[i].setX(mx[i]);
                    miss[i].setY(my[i]);
                }
                game.getChildren().remove(miss[i]);
            }
            mcount=0;
        }
        if (pcount==1) {
            game.getChildren().removeAll(speedup,missup);
            pcount=0;
        }
        px=145;
        py=280;
        player.setX(px);
        player.setY(py);
        p.setX(px-26);
        p.setY(py-25);
        s=0;
        nnum=0;
        L=1;
        dy=1;
        mm=1;
        speed=2;
        mnum=0;
        pause=0;
        score.setText("Score: " + s + "   Level: " + L);
        asttimer.delayProperty().setValue(Duration.seconds(5));
        asttimer.play();
        bg.play();
        str.play();
        thrust.seek(new Duration(0));
        thrust.play();
    }
    
    private void ast(){
        if (count>4) {
            asttimer.pause();
            return;
        }
        if(n[nnum]==0){
            int q = (int) (Math.random()*4)+1;
            String fname;
            fname = "src/images/" + Integer.toString(q) + ".png";
            asteroid[nnum] = new Image(new File(fname).toURI().toString());
            roid[nnum].setImage(asteroid[nnum]);

            x[nnum]= (int) (Math.random()*280)+10;
            ac[nnum].setCenterX(x[nnum]);
            roid[nnum].setX(x[nnum]-10);
            game.getChildren().addAll(ac[nnum],roid[nnum]);
            count++;
            n[nnum]=1;
            an[nnum].play();
        }
        else {
            for (int i=0;i<5;i++) {
                if (n[i]==0){
                    nnum=i;
                    ast();
                    return;
                }
            }
            return;
        }
        if(nnum==4) {
            nnum=0;
        }
        else{
            nnum=nnum+1;
        }
    }
    
    private void grab() {
        if(pcount==1) {
            for(int i=0;i<5;i++) {
                for(int k=0;k<10;k++) {
                    pxx[k]=px + k;
                    pyy[k]=py + k;
                    if(item==2) {
                        powx[i]=missup.getX() + i;
                        powy[i]=missup.getY() + i;
                        d[i]=Math.sqrt(Math.pow((pxx[k] - powx[i]),2) + Math.pow((pyy[k] - powy[i]),2));
                        if(d[i]<=10) {
                            mm=mm+1;
                            game.getChildren().remove(missup);
                            pcount=0;
                            return;
                        }
                    }
                    if(item==3){
                        powx[i]=speedup.getX() + i;
                        powy[i]=speedup.getY() + i;
                        d[i]=Math.sqrt(Math.pow((pxx[k] - powx[i]),2) + Math.pow((pyy[k] - powy[i]),2));
                        if(d[i]<=10) {
                            ss=ss+1;
                            speed=speed+1;
                            game.getChildren().remove(speedup);
                            pcount=0;
                            return;
                        }
                    }
                }
            }
        }
    }
    
    public void moveplayerleft(){
        if(pause>=1) {
            return;
        }
        if (px<speed) {
            px=0;
        }
        else{
            px=px-speed;
        }
        player.setX(px);
        p.setX(px-26);
        grab();
    }
    
    public void moveplayerright(){
        if(pause>=1) {
            return;
        }
        if (px>290-speed) {
            px=290;
        }
        else{
            px=px+speed;
        }
        player.setX(px);
        p.setX(px-26);
        grab();
    }
    
    public void moveplayerup(){
        if(pause>=1) {
            return;
        }
        if (py<speed) {
            py=0;
        }
        else{
            py=py-speed;
        }
        player.setY(py);
        p.setY(py-25);
        grab();
    }
    
    public void moveplayerdown(){
        if(pause>=1) {
            return;
        }
        if (py>290-speed) {
            py=290;
        }
        else{
            py=py+speed;
        }
        player.setY(py);
        p.setY(py-25);
        grab();
    }
    
    protected void missle(){
        if(pause>=1) {
            return;
        }
        if(mcount==mm) {
            return;
        }
        if(m[mnum]==0){
            mx[mnum]=px+4;
            my[mnum]=py-10;
            miss[mnum].setX(mx[mnum]);
            miss[mnum].setY(my[mnum]);
            game.getChildren().add(miss[mnum]);
            mcount++;
            fire.seek(new Duration(0));
            fire.volumeProperty().setValue(0.4);
            fire.play();
            missle[mnum].play();
            m[mnum]=1;
            if(mnum==4) {
                mnum=0;
            }
            else{
                mnum=mnum+1;
            }
        }
        
        
    }
    
    public void pause() {
        if(pause == 1) {
            str.play();
            bg.play();
            if(count<5) {
                asttimer.play();
            }
            for (int i=0;i<5;i++) {
                an[i].play();
            }
            if(mcount>0) {
                for (int i=0;i<5;i++) {
                    missle[i].play();
                }
            }
            pause=0;
            score.setText("Score: " + s + "   Level: " + L);
        }
        else if (pause==0){
            asttimer.stop();
            str.pause();
            bg.pause();
            for (int i=0;i<5;i++) {
                an[i].pause();
            }
            if(mcount>0) {
                for (int i=0;i<5;i++) {
                    missle[i].pause();
                }
            }
            pause=1;
            score.setText("Paused");
        }
    }
}

