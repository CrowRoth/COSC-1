import java.io.File;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.util.Duration;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class BallPane extends GridPane {
    public final double radius = 20;
    private double distance, px = 260, py = 260, x = radius, y = radius;
    private double dx = 1, dy = 1;
    private double speed = 0, s = 0, scoreCount;
    private Circle circle = new Circle(x, y, radius), player = new Circle (px, py, 40);
    private Timeline animation, speedSetter;
    private Pane game;
    private VBox con;
    private HBox scoreboard;
    private Label score, controls;
    protected MediaPlayer hit, bounce;

    public BallPane() {
        super();
        init();
        
        this.add(game, 0, 0);
        this.add(scoreboard, 0, 1);
        this.add(con, 1, 0);
    }
    
    private void init(){
        con = new VBox();
        scoreboard = new HBox();
        score = new Label("Ball Speed: " + speed + "Score: " + s);
        controls = new Label("Controls\n  \u2191 \u2193 \u2190 \u2192 to move\nEnter to start new game.");
        hit = new MediaPlayer(new Media(new File("src/audio/explosion.wav").toURI().toString()));
        bounce = new MediaPlayer(new Media(new File("src/audio/bounce.wav").toURI().toString()));
        
        initgame();
        initcontrols();
        initscores();
    }
    
    private void initgame(){
        circle.setFill(Color.GOLD); // Set ball color
        player.setFill(Color.BLUE);
         // Place a ball into this pane


        // Create an animation for moving the ball
        animation = new Timeline(
            new KeyFrame(Duration.millis(50), e -> moveBall()));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play(); // Start animation
        
        speedSetter = new Timeline(
            new KeyFrame(Duration.millis(2500), e -> increaseSpeed()));
        speedSetter.setCycleCount(Timeline.INDEFINITE);
        speedSetter.play();
        
        game = new Pane();
	    game.setMaxSize(250, 300);
        game.minHeightProperty().bind(game.heightProperty());
        game.minWidthProperty().bind(game.widthProperty());
        game.getChildren().add(player);
        game.getChildren().add(circle);
    }
    
    private void initcontrols(){
        con = new VBox(10); // the parameter to this constructor sets the space between children
		con.getChildren().addAll(controls);
        
    }
    
    private void initscores(){
        scoreboard = new HBox(10); // the parameter to this constructor sets the space between children
		scoreboard.getChildren().addAll(score);
        
    }

    public void pause() {
        if (animation.getCurrentRate() == 0.0){
            animation.play();
            speedSetter.play();
        }
        else {
            score.setText("Game is Paused");

            animation.pause();
            speedSetter.pause();
        }
    }

    public void increaseSpeed() {
        animation.setRate(animation.getRate() + 1.0);
    }

    public void moveplayerup() {
        if (py < 60){
            py = 40;
        }
        else{
            py = py - 20;
        }
        
        player.setCenterY(py);
    }

    public void moveplayerdown() {
        if (py > 300 - 60){
            py = 300 - 40;
        }
        else{
            py = py + 20;
        }
        player.setCenterY(py);
    }
    
    public void moveplayerleft() {
        if (px < 60){
            px = 40;
        }
        else{
            px = px - 20;
        }
        
        player.setCenterX(px);
    }
    
    public void moveplayerright() {
        if (px > 250 - 60){
            px = 250 - 40;
        }
        else{
            px = px + 20;
        }
        player.setCenterX(px);
    }
    
    protected void moveBall() {
      // Check boundaries
        scoreCount += animation.getRate();
        s = scoreCount/100.0;
        speed = animation.getRate();
        score.setText("Ball Speed: " + speed + "Score: " + s);
        
        distance = Math.sqrt(Math.pow((x - px),2) + Math.pow((y - py),2));
        if (x < radius || x > 250 - radius) {
            dx *= -1;
            bounce.seek(new Duration(0));
            bounce.play();// Change ball move direction
        }
        if (y < radius || y > 300 - radius) {
            dy *= -1;
            bounce.seek(new Duration(0));
            bounce.play();// Change ball move direction
        }
        if (distance <= 60){
            circle.setFill(Color.RED);
            animation.stop();
            speedSetter.stop();
            hit.seek(new Duration(0));
            hit.play();
        }

        // Adjust ball position
        x += dx;
        y += dy;
        circle.setCenterX(x);
        circle.setCenterY(y);
    }
    
    public void reset() {
        if (distance <= 60){
            circle.setFill(Color.GOLD);
            x = radius;
            y = radius;
            px = 260;
            py = 260;
            scoreCount = 0;
            s = 0;
            
            
            score.setText("Ball Speed: " + speed + "Score: " + s);
            player.setCenterX(px);
            player.setCenterY(py);
            animation.setRate(1);
            animation.play();
            speedSetter.play();
        }
    }
    
  }