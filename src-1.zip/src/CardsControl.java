import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class CardsControl extends Application {
  @Override 
  public void start(Stage primaryStage) {
    CardPane cPane = new CardPane(); 

    
    

   
    Scene scene = new Scene(cPane, 600, 600);
    primaryStage.setTitle("Cards"); 
    primaryStage.setScene(scene); 
    primaryStage.show(); 
    
   
    cPane.requestFocus();
  }

  
  public static void main(String[] args) {
    launch(args);
  }
}
