import java.io.File;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.util.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class Badapaka extends GridPane {
    private int s=0,n=0,pause=0,count=0,L=1;
    private double dy=1,mx=149,my=276,px=145,py=280,m=0,r=0;
    private double[] x = new double[5],y = new double[5],mxx= new double[3],pxx= new double[10],pyy = new double[10],d= new double[5];
    private Circle[] ac=new Circle[5];
    private Rectangle m1,player = new Rectangle(px,py,10,10);
    private Pane game;
    private Timeline[] an= new Timeline[5];
    private Timeline asttimer,missle;
    Label Level,score = new Label("Score: " + s + "   Level: " + L);
    protected MediaPlayer a;
    
    public Badapaka(){
        super();
        init();
        
        
        this.add(game,0,0);
        this.add(score,0,1);
    }
    
    private void init(){
        a = new MediaPlayer(new Media(new File("src/audio/aexp1.mp3").toURI().toString()));
        a.setOnError(() -> System.out.println("Error : " + a.getError().toString()));
        
        initgame();
    } 
    
    private void initgame(){
        player.setFill(Color.BLUE);
        for(int i=0;i<5;i++) {
            x[i]=0;
            y[i]=0;
            ac[i]= new Circle(x[n],y[n],10);
            ac[i].setFill(Color.GREY);
        }
        
        asttimer = new Timeline(
        new KeyFrame(Duration.millis(500), e -> ast()));
        asttimer.setCycleCount(Timeline.INDEFINITE);
        asttimer.delayProperty().setValue(Duration.seconds(5));
        asttimer.play();
        
        an[0] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(0)));
        an[0].setCycleCount(Timeline.INDEFINITE);
        
        an[1] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(1)));
        an[1].setCycleCount(Timeline.INDEFINITE);
        
        an[2] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(2)));
        an[2].setCycleCount(Timeline.INDEFINITE);
        
        an[3] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(3)));
        an[3].setCycleCount(Timeline.INDEFINITE);
        
        an[4] = new Timeline(
        new KeyFrame(Duration.millis(50), e -> moveast(4)));
        an[4].setCycleCount(Timeline.INDEFINITE);
        
        missle = new Timeline(
        new KeyFrame(Duration.millis(25), e -> movemissle()));
        missle.setCycleCount(Timeline.INDEFINITE);
        
        game = new Pane();
        game.setMaxSize(300, 300);
        game.minHeightProperty().bind(game.heightProperty());
        game.minWidthProperty().bind(game.widthProperty());
        
        Level = new Label("Level: " + L);
        Level.layoutXProperty().bind(game.widthProperty().subtract(game.widthProperty()).divide(2));
        Level.layoutYProperty().bind(game.heightProperty().subtract(game.heightProperty()).divide(2));
        
        r=asttimer.getRate();
        game.getChildren().add(Level);
        
        if(r>0){
            game.getChildren().remove(Level);
        }
        game.getChildren().add(player);
    }
    protected void moveast(int z){
        for(int i=0;i<5;i++) {
            for(int k=0;k<10;k++) {
                pxx[k]=px + k;
                pyy[k]=py + k;
                d[i]=Math.sqrt(Math.pow((pxx[k] - x[i]),2) + Math.pow((pyy[k] - y[i]),2));
                if(d[i]<=10) {
                    reset();
                    px=145;
                    py=280;
                    player.setX(px);
                    player.setY(py);
                    return;
                }
            }
        }
        if(y[z]==290){
            game.getChildren().remove(ac[z]);
            count--;
            an[z].pause();
            y[z]=0;
            ac[z].setCenterY(y[z]);
            n=z;
            ast();
        }
        else{
            y[z] += dy;
        }
        ac[z].setCenterY(y[z]);
    }
    
    
    protected void movemissle() {
        for(int i=0;i<5;i++) {
            for(int k=0;k<3;k++) {
                mxx[k]=mx + k;
                d[i]=Math.sqrt(Math.pow((mxx[k] - x[i]),2) + Math.pow((my - y[i]),2));
                if(d[i]<=10) {
                    an[i].pause();    
                    game.getChildren().remove(ac[i]);
                    count--;
                    y[i]=0;
                    ac[i].setCenterY(y[i]);
                    missle.pause();
                    game.getChildren().remove(m1);
                    m--;
                    a.seek(new Duration(0));
                    a.play();
                    s++;
                    score.setText("Score: " + s + "   Level: " + L);
                    n=i;
                    Level();
                    return;
                }
            }
        }
            
        if (my == 0){
            missle.pause();
            game.getChildren().remove(m1);
            m--;
        }
        else{
            my = my - 1;
        }
        
        m1.setY(my);
    }
    
    protected void Level(){
        switch(s){
            case 1:
                int k=s;
                reset();
                s=k;
                L=2;
                score.setText("Score: " + s + "   Level: " + L);
                dy=2;
                return;
            case 30:
                return;
            case 40:
                break;
            case 45:
                return;
            default:
                ast();
                break;
        }
    }
    
    protected void reset(){
        asttimer.stop();
        for(int i=0;i<5;i++){
            an[i].pause();
            y[i]=0;
            ac[i].setCenterY(y[i]);
            game.getChildren().remove(ac[i]);
        }
        s=0;
        n=0;
        L=1;
        dy=1;
        score.setText("Score: " + s + "   Level: " + L);
        asttimer.delayProperty().setValue(Duration.seconds(5));
        asttimer.play();
    }
    
    private void ast(){
        x[n]= (int) (Math.random()*280)+10;
        ac[n].setCenterX(x[n]);
        game.getChildren().addAll(ac[n]);
        count++;
        an[n].play();
        if(n==4) {
            asttimer.pause();
            n=0;
        }
        else{
            n=n+1;
        }
    }
    
    public void moveplayerleft(){
        if(pause==1) {
            return;
        }
        if (px<2) {
            px=0;
        }
        else{
            px=px-2;
        }
            player.setX(px);
    }
    
    public void moveplayerright(){
        if(pause==1) {
            return;
        }
        if (px>288) {
            px=290;
        }
        else{
            px=px+2;
        }
        player.setX(px);
    }
    
    public void moveplayerup(){
        if(pause==1) {
            return;
        }
        if (py<2) {
            py=0;
        }
        else{
            py=py-2;
        }
        player.setY(py);
    }
    
    public void moveplayerdown(){
        if(pause==1) {
            return;
        }
        if (py>288) {
            py=290;
        }
        else{
            py=py+2;
        }
        player.setY(py);
    }
    
    protected void missle(){
        if(pause==1) {
            return;
        }
        if(m>0) {
            return;
        }
        else{
        mx=px+4;
        my=py-4;
        m1 = new Rectangle(mx,my,2,4);
        m1.setFill(Color.RED);
        game.getChildren().add(m1);
        m++;
        missle.play();
        }
    }
    
    public void pause() {
        if(pause == 1) {
            if(count<5) {
                asttimer.play();
            }
            for (int i=0;i<5;i++) {
                an[i].play();
            }
            if(m>0) {
                missle.play();
            }
            pause=0;
            score.setText("Score: " + s + "   Level: " + L);
        }
        else{
            asttimer.pause();
            for (int i=0;i<5;i++) {
                an[i].pause();
            }
            if(m>0) {
                missle.pause();
            }
            pause=1;
            score.setText("Paused");
        }
    }
}

